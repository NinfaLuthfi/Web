<template>
  <div class="bg-blue p-10 lg:p-36">
    <h1 class="text-white text-4xl mb-5">
      Free ecommerce template for Vue.js projects
    </h1>
    <h2 class="text-white text-2xl">
      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
    </h2>
  </div>
</template>
